package kyr;

public enum WasteMode {

}
